const form = document.getElementById("clientForm");
const list = document.getElementById("clientList");

async function loadClients() {
  const res = await fetch("/clients");
  const clients = await res.json();
  list.innerHTML = "";
  clients.forEach(c => {
    const li = document.createElement("li");
    li.textContent = `${c.name} - ${c.email} - ${c.phone}`;
    list.appendChild(li);
  });
}

form.addEventListener("submit", async e => {
  e.preventDefault();
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const phone = document.getElementById("phone").value;

  await fetch("/clients", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, phone })
  });

  form.reset();
  loadClients();
});

loadClients();